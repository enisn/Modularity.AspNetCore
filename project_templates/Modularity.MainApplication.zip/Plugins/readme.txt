﻿
All module's dll files must be placed here with dependencies of modules.

This folder will be loaded at runtime. All dll files will be loaded and Controllers will be mapped.