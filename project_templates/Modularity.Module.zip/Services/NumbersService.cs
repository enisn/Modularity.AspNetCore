﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Services
{
    public class NumbersService
    {
        public IEnumerable<int> GetNumbers()
        {
            for (int i = 0; i < 32; i++)
            {
                yield return i;
            }
        }
    }
}
