﻿using Microsoft.AspNetCore.Mvc;
using $safeprojectname$.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class NumbersController : ControllerBase
    {
        public NumbersController(NumbersService numbersService)
        {
            this.NumbersService = numbersService;
        }

        public NumbersService NumbersService { get; }

        [HttpGet]
        public IActionResult Get()
        {
            var numbers = NumbersService.GetNumbers().ToList();
            return Ok(numbers);
        }
    }
}
